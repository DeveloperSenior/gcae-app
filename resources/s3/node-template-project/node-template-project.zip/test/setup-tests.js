/** Auto Generated 
 * @author Andres Felipe Escobar López
 * @date 2024
 * @copyright Tecnologico de Antioquia 2024
 */

const dotenv = require('dotenv');
dotenv.config({ path: './.env.test' });